/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "arm_math.h"
#include "math.h"
#include "MY_LIS3DSH.h"
#include "string.h"
#include <stdlib.h>
#include "kann.h"
#include "kautodiff.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
kann_t *my_model(int n_in, int n_hidden1,int n_hidden2);
void Feature_Extraction(float32_t xx[]);
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart4;

/* USER CODE BEGIN PV */


#define NUM_SAMPLES 2048
#define N 100 //number of Training samples
#define M 300  //number of test samples
#define no_iteration 4
uint8_t ON_Level = 40;
float32_t MSE_train[N*no_iteration]={0};   // N*no_iteration
float32_t MSE_test[M]={0};
float32_t training_datas[N*no_iteration][87];
float32_t test_datas[M][87];

//just for evaluating once
//float32_t mean_training_data2=0;
//float32_t *pmean_training_data2=&mean_training_data2;
//float32_t std_training_data2=0;
//float32_t *pstd_training_data2=&std_training_data2;
//float32_t MSE_train2[N*no_iteration]={0};


extern float train_costs[], val_costs[];
extern int ab;
int epoch[no_iteration] = {0};
float32_t train_costs1[500]= {0};
float32_t val_costs1[500] = {0};
uint32_t last_batch_epoch =0;
float32_t training_times[no_iteration] = {0};


int16_t x,y,z;
//float xg,yg,zg;

float32_t xyz[2048];
//float32_t ygg[2048];
//float32_t zgg[2048];

//int ygg[10000];

//float32_t yyy[2048];
float32_t xxx[2048];
float32_t xxx2[2048];
//float32_t yyy2[2048];

float32_t absxxx=0;
//float32_t pabsxxx=&absxxx[2048];

float32_t sumx=0;
//float32_t sumy=0;

float32_t sumabsx=0;

float32_t meanx=0;
//float32_t meany=0;

float32_t *pmeanx=&meanx;
//float32_t *pmeany=&meany;

float32_t stdx=0;
//float32_t stdy=0;

float32_t *pstdx=&stdx;
//float32_t *pstdy=&stdy;

float32_t maxx=0;
float32_t *pmaxx=&maxx;

uint32_t Imaxx=0;
uint32_t *pImaxx=&Imaxx;

float32_t minx=0;
float32_t *pminx=&minx;

uint32_t Iminx=0;
uint32_t *pIminx=&Iminx;

float32_t X_ppv=0;

float32_t maxabsx=0;
float32_t *pmaxabsx=&maxabsx;

uint32_t Imaxabsx=0;
uint32_t *pImaxabsx=&Imaxabsx;

//float32_t *pxxx2=&xxx2[2048];

// ss00 and ss10
float32_t ss00[2051]={0};

float32_t s10[1027]={0};
//t11 and tt11
float32_t t11[1027]={0};
//s20 and ss20
float32_t s20[515]={0};

float32_t t21[515]={0};

float32_t s22[515]={0};
float32_t t23[515]={0};

float32_t s30[260]={0};
float32_t t31[260]={0};

float32_t s32[260]={0};
float32_t t33[260]={0};

float32_t s34[260]={0};
float32_t t35[260]={0};

float32_t s36[260]={0};
float32_t t37[260]={0};

float32_t energy[16]={0};



int Sample_Number=0;

int v=1;

float32_t df=0.78125;
//float32_t sqrtabsx[2048];

//float32_t *psqrtabsx=&sqrtabsx[2048];

float32_t xsr=0;
float32_t xsr1=0;
float32_t *pxsr=&xsr;

float32_t a=0;
float32_t *pa=&a;

float32_t sumx2=0;
float32_t sumy2=0;

float32_t X_RMS=0;
float32_t *pX_RMS=&X_RMS;

float32_t X_kv=0;
float32_t X_sv=0;
float32_t X_cf=0;
float32_t X_if=0;
float32_t X_sf=0;
float32_t X_kf=0;
float32_t X_fc=0;
float32_t X_rmsf=0;
float32_t X_rvf=0;
float32_t X_sra;
float32_t X_mf=0;
float32_t sqrtPro=0;
float32_t *psqrtPro=&sqrtPro;

float32_t *pX_rmsf=&X_rmsf;
float32_t *pX_rvf=&X_rvf;

float32_t xfc1=0;
float32_t xfc2=0;
float32_t xrmsf1=0;
float32_t xrvf1=0;
float32_t feature[29]={0};



float32_t leftFFT[2*NUM_SAMPLES];
float32_t fftx[NUM_SAMPLES];

float32_t features_xyz[29]={0};

float32_t **training_data;
float32_t **test_data;


float32_t STD_X =0;


float32_t find_max_element[N]={0};

float32_t MSE_monitoring =0;
//float32_t store_data[87]={0};

uint8_t axis = 1;

float32_t max_features[87]={0};

float32_t mean_training_data=0;
float32_t *pmean_training_data=&mean_training_data;

float32_t std_training_data=0;
float32_t *pstd_training_data=&std_training_data;
//float32_t A[10][87]={0};
//float32_t B[30][87]={0};

//float32_t E[N*29]={0};
//float32_t EE[1015]={0};

//float32_t ET[1015]={0};
//float32_t Etest[1015]={0};
//float32_t m[29]={0};

//float32_t A[29]={0};
//float32_t B[29]={0};
//float32_t C[29]={0};

//float32_t sigma[841]={0};
//float32_t sigma0[841]={0};

//float32_t probability[N]={0};
//float32_t probability1[1]={0};
//float32_t test_probability[200]={0};
//float32_t aalert_probability[M]={0};
//float32_t alert_probability[M-1]={0};

//arm_matrix_instance_f32 pA;
//arm_matrix_instance_f32 pB;
//arm_matrix_instance_f32 pC;

//arm_matrix_instance_f32 psigma;
//arm_matrix_instance_f32 psigma0;
//arm_matrix_instance_f32 pinv_sigma;
//arm_matrix_instance_f32 pprobability1;



//float32_t stdpro=0;
//float32_t *pstdpro=&stdpro;

//float32_t meanpro=0;
//float32_t *pmeanpro=&meanpro;

//float32_t t_alpha=0;
//float32_t delta=0;
//float32_t ta=0;
//float32_t L=0;
//float32_t LL=0;

//float32_t alert_level=0;
//float32_t *palert_level=&alert_level;

//uint32_t Ialert_level=0;
//uint32_t *pIalert_level=&Ialert_level;


//float32_t maxpro=0;
//float32_t *pmaxpro=&maxpro;

//uint32_t Imaxpro=0;
//uint32_t *pImaxpro=&Imaxpro;


uint8_t  train=0;
uint32_t ind_mes=0;
uint32_t ind_training_data=0;
uint8_t index1 = 0;

//uint8_t b[10]={1,2,3,4,5,6,7,8,9,10,44,50,100};
int i,ii=0;
int counter=0;
uint8_t Data_acquisition=1;
uint8_t percent=0;

arm_status status_mu;
arm_status status_add;

int Xpos_gauge =0;
int Ypos_gauge =0;
int radius_gauge[8]={0,0,0,55,48,39,28,16};
float32_t theta=0;
HAL_StatusTypeDef return_val;

float32_t fault_probability=0;
//float32_t *pfault_probability=&fault_probability;

int Fault_percentage=0;

float32_t anomaly_threshold= 3;

uint8_t flag=1;
int i=0;
char text[20];
//float32_t ypredict[87]={0};

float32_t train_costs[200], val_costs[200];
int ab;
uint16_t training_time=0;
float32_t test =0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM2_Init(void);
static void MX_UART4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
LIS3DSH_DataScaled myData;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	LIS3DSH_InitTypeDef myAccConfigDef;
  /* USER CODE END 1 */
  

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_TIM2_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */

  myAccConfigDef.dataRate = LIS3DSH_DATARATE_1600;           //set the sample rate
  myAccConfigDef.fullScale = LIS3DSH_FULLSCALE_4;
  myAccConfigDef.antiAliasingBW = LIS3DSH_FILTER_BW_800;    //set the BW of accelerometer
  myAccConfigDef.enableAxes = LIS3DSH_XYZ_ENABLE;           // turn on axis which you want to sample
  myAccConfigDef.interruptEnable = true;                    //turn on the accelerometer interrupt
  LIS3DSH_Init(&hspi1, &myAccConfigDef);


  // auto encoder init

    kann_t *ann;
    ann = my_model(87,40,25);
    training_data = (float32_t**)malloc(N * sizeof(float32_t*));
    for (int k = 0; k < N; k++)
    {
        training_data[k] = (float32_t*)malloc(87 * sizeof(float32_t));
    }

    test_data = (float32_t**)malloc(1 * sizeof(float32_t*));
    for (int k = 0; k < 1; k++)
    {
        test_data[k] = (float32_t*)malloc(87 * sizeof(float32_t));
    }


  	    //HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
  	    //HAL_TIM_Base_Start(&htim2);
  	    //training_time = __HAL_TIM_GET_COUNTER(&htim2); // APB1 is the clock source for timer 2 which is 30 MHz.
  	    //HAL_Delay(5000);
		//training_time = __HAL_TIM_GET_COUNTER(&htim2) - training_time;
		//HAL_TIM_Base_Stop(&htim2);
		//HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);

  /* USER CODE END 2 */
 
 

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  	  	  	  	  if(i>=2048)
	  	  	  	  	  {
	  	  	  	  	  		flag=0;
	  	  	  	  	  		i=0;
	  	  	  	  	  			if(axis==1)
	  							{
	  								Feature_Extraction(xyz);
	  								STD_X = stdx;
	  								for(int k=0; k<29 ; k++)
	  								{
	  									 features_xyz[k] = feature[k];
	  								}
	  								if(Sample_Number<N && STD_X > ON_Level)
	  								{
	  									 for(int k=0; k<29 ; k++)
	  									 {
	  									  	  training_data[Sample_Number][k]=features_xyz[k];
	  									 }
	  								}
	  								if(Sample_Number>=N && STD_X > ON_Level)
	  								{
	  									 for(int k=0; k<29 ; k++)
	  									 {
	  									  	  //test_datas[Sample_Number-N][k]=features_xyz[k]/max_features[k];
	  										 	 test_data[0][k]=features_xyz[k]/max_features[k];
	  									 }
	  								}
	  								if(STD_X > ON_Level)
	  								{
	  								  HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);

	  								}
	  								else
	  								{
		  							  HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);

	  								}

	  	  	  	  	  			}
	  	  	  	  	  			else if(axis==2)
	  	  	  	  	  			{
	  	  	  	  	  		         Feature_Extraction(xyz);
	  	  	  	  	  			  	 for(int k=0; k<29 ; k++)
	  	  	  	  	  			  	 {
	  	  	  	  	  			  	  	  features_xyz[k] = feature[k];
	  	  	  	  	  			  	 }
	  	  	  	  	  			  	 if(Sample_Number<N && STD_X > ON_Level)
	  	  	  	  	  			  	 {
	  	  	  	  	  			  	  	  for(int k=0; k<29 ; k++)
	  	  	  	  	  			  	  	  {
	  	  	  	  	  			  	  	  	  training_data[Sample_Number][k+29]=features_xyz[k];
	  	  	  	  	  			  	  	  }
	  	  	  	  	  			  	 }
	  	  	  	  	  			  	 if(Sample_Number>=N && STD_X > ON_Level)
	  	  	  	  	  			  	 {
	  	  	  	  	  			  	  	  for(int k=0; k<29 ; k++)
	  	  	  	  	  			  	  	  {
	  	  	  	  	  			  	  	  	  //test_datas[Sample_Number-N][k+29]=features_xyz[k]/max_features[k+29];
	  	  	  	  	  			  	  		  test_data[0][k+29]=features_xyz[k]/max_features[k+29];
	  	  	  	  	  			  	  	  }
	  	  	  	  	  			  	 }
	  	  	  	  	  			}

	  	  	  	  	  			else if(axis==3)
	  	  	  	  	  			{
	  	  	  	  	  				Feature_Extraction(xyz);
	  	  	  	  	  			  	for(int k=0; k<29 ; k++)
	  	  	  	  	  			  	{
	  	  	  	  	  			  	  	 features_xyz[k] = feature[k];
	  	  	  	  	  			  	}
	  	  	  	  	  			  	if(Sample_Number<N && STD_X > ON_Level)
	  	  	  	  	  			    {
	  	  	  	  	  			  		for(int k=0; k<29 ; k++)
	  	  	  	  	  				  	{
	  	  	  	  	  				  	  	training_data[Sample_Number][k+58]=features_xyz[k];
	  	  	  	  	  				  	}
	  	  	  	  	  			    }
	  	  	  	  	  			  	if(Sample_Number>=N && STD_X > ON_Level)
	  	  	  	  	  			    {
	  	  	  	  	  			  		for(int k=0; k<29 ; k++)
	  	  	  	  	  				  	{
	  	  	  	  	  				  	  	//test_datas[Sample_Number-N][k+58]=features_xyz[k]/max_features[k+58];
	  	  	  	  	  			  			test_data[0][k+58]=features_xyz[k]/max_features[k+58];
	  	  	  	  	  				  	}
	  	  	  	  	  			    }
	  	  	  	  	  			  	if(STD_X > ON_Level)
	  	  	  	  	  			  	{
	  	  	  	  	  			  		Sample_Number++;
	  	  	  	  	  			  	}
	  	  	  	  	  			}

	  	  	  	  	  	a=5;
	  	  	  	  	  	axis++;
	  	  	  	  	  	if(Sample_Number<N && axis==4)
	  	  	  	  	  	{
	    	          	  	  //BSP_LCD_SetTextColor(LCD_COLOR_GREEN );
	    	          		  percent=(Sample_Number*100/N);

	  // show the progress bar
	    	          		 // BSP_LCD_FillRect(14,101,floor(214/N),20);
	    	          		  //BSP_LCD_FillRect(2*percent+14,101,floor(214/N),20);


	    	          		  //sprintf((char*)text, "%d", percent);
	    	          		  //BSP_LCD_SetTextColor(LCD_COLOR_DARKBLUE );
	    	          		  //BSP_LCD_SetBackColor(LCD_COLOR_WHITE);
	    	          		  //BSP_LCD_SetFont(&Font16);

	    	          		  //BSP_LCD_DisplayStringAt(0,130,(uint8_t*)" Progress",LEFT_MODE);
	    	          		  //BSP_LCD_DisplayStringAt(0,130,(uint8_t*)&"    %",CENTER_MODE);
	    	          		  //BSP_LCD_DisplayStringAt(0,130,(uint8_t*)&text,CENTER_MODE);

	  	  	  	  	  	}
	  // train the autoencoder
	  	    		  	if((Sample_Number==N) && (train<no_iteration))
	  	    		  	{




	  	  	          	    for(int j = 0; j<87;j++)
	  	  	          		{
	  	  	          	    	for(int k = 0; k<N;k++)
	  	  	          	    	{
	  	  	          	    		find_max_element[k]=training_data[k][j];
	  	  	          	    	}
	  		  	          	    arm_max_f32(find_max_element,N,pmaxx,pImaxx);

	  		  	          	    if(maxx>max_features[j])
	  		  	          	    {
	  		  	          	    	max_features[j]= maxx;
	  		  	          	    }

	  		  	          	    for(int k = 0; k<N;k++)
	  		  	          		{
	  		  	          		  	training_data[k][j]=training_data[k][j]/max_features[j];
	  		  	          		}
	  	  	          		}

	  	  	          	    for(int k = 0; k<N;k++)
	  	  	          		{
	  	  	          	    	for(int j = 0; j<87;j++)
	  	  	          	    	{
	  	  	          	    		training_datas[train*N+k][j]=training_data[k][j];
	  	  	          	    	}
	  	  	          		}

	  	  	          	    HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET);
	  	  	          	    HAL_TIM_Base_Start(&htim2);
	  	  	          	    training_time = __HAL_TIM_GET_COUNTER(&htim2); // APB1 is the clock source for timer 2 which is 30 MHz.
// I set the prescaler to 30000 so the timer counts every 2 ms. the dimension of training_time is ms.
	  	  	          	    if(train==0)
	  	  	          	    {
	  	  	          	    	kann_train_fnn1(ann, 0.001f, 1, 150, 10, 0.1f, N, training_data, training_data);
	  	  	          	    }
	  	  	          	    else
	  	  	          	    {
	  	  	          	    	kann_train_fnn1(ann, 0.001f, 1, 50, 10, 0.1f, N, training_data, training_data);
	  	  	          	    }
	  	    		  		training_time = __HAL_TIM_GET_COUNTER(&htim2) - training_time;
	  	    		  		HAL_TIM_Base_Stop(&htim2);
							HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);

							training_times[train] = training_time*2;
						    for(int j=0;j<ab;j++)
						    {
						        train_costs1[j]=train_costs[j];
						        val_costs1[j]=val_costs[j];
						    }
						    epoch[train] = ab-last_batch_epoch;
						    last_batch_epoch = ab;
	  	    		  	    a=2;
	  // find MSE of train data
	  	    		  	    for(int k = 0; k<N;k++)
	  	    		  	    {
	  	    		  	    	const float *y_pred;
	  	    		  	    	y_pred = kann_apply1(ann, training_data[k]);
	  	    		  	    	for(int j = 0; j<87 ; j++)
	  	    		  	    	{
	  	    		  	    		MSE_train[train*N+k]+=(y_pred[j]-training_data[k][j])*(y_pred[j]-training_data[k][j]);
	  	    		  	    		//ypredict[j]=y_pred[j];
	  	    		  	    	}
	  	    		  	    }


	  //store data into flash memory
	  	    		  	    //BSP_LCD_DisplayStringAt(0,130,(uint8_t*)&"Storing Data in Flash",CENTER_MODE);
	  	    		  	    //ind_mes = train*N*4 +1;
	  	    		  	    //MY_FLASH_SetSectorAddrs(6,0x08040000);
	  	    		  	  	//MY_FLASH_WriteN(ind_mes,MSE_train,N,DATA_TYPE_32);

	  	    		  	  	//for(int k = 0; k<N;k++)
	  	    		  	  	//{
	  	    		  	  		//for(int j = 0; j<87;j++)
	  	    		  	  		//{
	  	    		  	  		//	store_data[j]=training_data[k][j];
	  	    		  	  		//}
	  	    		  	  	//ind_training_data = train*N*87*4 + k*87*4+1;
	  	    		  	  	//MY_FLASH_SetSectorAddrs(7,0x08060000);
	  	    		  	  	//MY_FLASH_WriteN(ind_training_data,store_data,87,DATA_TYPE_32);
	  	    		  	  	//}


	  	    		  	    train++;
	  	    		  	    if(train == no_iteration)
	  	    		  	    {
	  	    		  	    	arm_mean_f32(MSE_train,N*no_iteration,pmean_training_data);
	  	    		  		  	arm_std_f32(MSE_train,N*no_iteration,pstd_training_data);
	  	    		  		  	for(int k = 0; k<N*no_iteration;k++)
	  	    		  		  	{
	  	    		  		  	    MSE_train[k]=(MSE_train[k]-mean_training_data)/std_training_data;
	  	    		  		  	}
	  	    		  		  	// just for evaluating once
	  	    		  		  	/*for(int k = 0; k<N*no_iteration;k++)
	  	    		  			{
	  	    		  			  	const float *y_pred;
	  	    		  			  	y_pred = kann_apply1(ann, training_datas[k]);
	  	    		  			  	for(int j = 0; j<87 ; j++)
	  	    		  			  	{
	  	    		  			  	   MSE_train2[k]+=(y_pred[j]-training_datas[k][j])*(y_pred[j]-training_datas[k][j]);
	  	    		  			  	}
	  	    		  			}
	  	    		  		  	arm_mean_f32(MSE_train2,N*no_iteration,pmean_training_data2);
	  	    		  			arm_std_f32(MSE_train2,N*no_iteration,pstd_training_data2);
	  	    		  			for(int k = 0; k<N*no_iteration;k++)
	  	    		  			{
	  	    		  			  	MSE_train2[k]=(MSE_train2[k]-mean_training_data2)/std_training_data2;
	  	    		  			}
	  	    		  			*/
	  	    		  	    }

	  	    		  	    if(train<no_iteration)
	  	    		  	    {
	  	    		  	    	Sample_Number=0; 	  // train again using new batch
	  	    		  	    }

	  	    		  	} //end of training

//---------------------------------------------//start monitoring the device//------------------------------------

	  	    		    if(Sample_Number>=N && train>=no_iteration && axis==4 && STD_X > ON_Level)
	  	    		    {
	  //calculating the MSE of the test
	  	    		    		index1 = Sample_Number-N;
	  	  	          	    	for(int j = 0; j<87;j++)
	  	  	          	    	{
	  	  	          	    		test_datas[index1][j]=test_data[0][j];
	  	  	          	    	}


	  	    		    		//for(int j = 0; j<87 ; j++)
	  	    		    		//{
	  	    		    			//test_datas1[index1][j] = test_datas[index1][j];
	  	    		    			//test_data[0][j]=test_datas[index1][j]/max_features[j];
	  	    		    			//test_datas[index1][j]=test_datas[index1][j]/max_features[j];
	  	    		    		//}

	  	    		    		const float *y_pred;
	  	    		    		y_pred = kann_apply1(ann, test_data[0]);
	  	    		    		for(int j = 0; j<87 ; j++)
	  	    		    		{
	  	    		    			MSE_test[index1]+=(y_pred[j]-test_data[0][j])*(y_pred[j]-test_data[0][j]);
	  	    		    		}

	  	    		    		MSE_test[index1]=(MSE_test[index1]-mean_training_data)/std_training_data;

	  //calculating the percentage of fault
	  		  	  	        	fault_probability=((MSE_test[index1]-anomaly_threshold)/MSE_test[index1])*100;
	  		  	  	        	if(fault_probability<0)
	  		  	  	        		fault_probability=0;

	  		  	  	        	Fault_percentage=(int)floor(fault_probability);

	  	    		    }//end of monitoring

	  	  	  	  	  	if(axis==4)
	  	  	  	  	  	{
							//HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_SET);
	  	  	  	  	  	    //HAL_Delay(2000);
							//HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET);
	  	  	  	  	  		if((remainderf(Sample_Number,10) ==0 ) & (Sample_Number!=0))
	  	  	  	  		  	{
	  	  	  	  				HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_SET);
	  	  	  	  		  	  	HAL_Delay(8000);
	  	  	  	  				HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET);
	  	  	  	  		  	}
	  	  	  	  	  		axis=1;
	  	  	  	  	  	}
	  	  	  	  	  		//test = remainderf(Sample_Number,10) ;

	  	    		    a=6;
	  	    		    flag=1;
	  	 } // end of if


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /** Supply configuration update enable 
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);
  /** Configure the main internal regulator output voltage 
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 60;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV16;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_UART4|RCC_PERIPHCLK_SPI1;
  PeriphClkInitStruct.Spi123ClockSelection = RCC_SPI123CLKSOURCE_PLL;
  PeriphClkInitStruct.Usart234578ClockSelection = RCC_USART234578CLKSOURCE_D2PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 0x0;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  hspi1.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi1.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi1.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi1.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi1.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi1.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi1.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 60000-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 65536-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  huart4.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart4.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart4.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart4, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart4, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOE_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LED1_Pin|LED3_Pin|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : LED1_Pin LED3_Pin PB6 */
  GPIO_InitStruct.Pin = LED1_Pin|LED3_Pin|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PC7 */
  GPIO_InitStruct.Pin = GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LED2_Pin */
  GPIO_InitStruct.Pin = LED2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED2_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */

kann_t *my_model(int n_in, int n_hidden1,int n_hidden2)
{

    kad_node_t *t;
    //xx = kad_feed(2, 1, n_features);
    t = kann_layer_input(n_in);
    t = kad_tanh(kann_layer_dense(t,n_hidden1 ));
    t = kad_sigm(kann_layer_dense(t,n_hidden2));
    t = kad_tanh(kann_layer_dense(t,n_hidden1 ));
    //t = kad_sigm(t);
    //t = kad_sigm(kann_layer_dense(t,n_in));
    //t = kad_ce_bin(t, xx);
	t = kann_layer_cost(t, n_in, KANN_C_MSE);
	return kann_new(t, 0);
}

void Feature_Extraction(float32_t xx[])
{
  	  	  arm_mean_f32(xx,2048,pmeanx);
  	  	  for(int k=0;k<2048;k++)
	  	  {
		  xxx[k]=xx[k]-meanx;
		  xxx2[k]=xx[k]-meanx;
		  ss00[k+1]=xx[k]-meanx;
	  	  }
// ----------------------------------------------time domain features-----------------------------------------

  	  	  arm_std_f32(xxx2,2048,pstdx);
//	  		  	  	     									 X_RMS
  	      for(int k=0;k<2048;k++)
  		  {


	  	     X_kv=((xxx2[k])/stdx)*((xxx2[k])/stdx)*((xxx2[k])/stdx)*((xxx2[k])/stdx)+X_kv;
	  	     X_sv=((xxx2[k])/stdx)*((xxx2[k])/stdx)*((xxx2[k])/stdx)+X_sv;

  	    	 sumx2=sumx2+xxx2[k]*xxx2[k];

  	    	 absxxx=fabs(xxx2[k]);
  	    	 sumabsx=sumabsx+absxxx;
  	    	 if(absxxx>maxabsx)
  	    	 {
  	    		 maxabsx=absxxx;
  	    	 }

  	    	 arm_sqrt_f32(absxxx,pxsr);
  	    	 xsr1=xsr1+xsr;
  		  }

  	      arm_max_f32(xxx2,2048,pmaxx,pImaxx);
  	      arm_min_f32(xxx2,2048,pminx,pIminx);

  	      arm_sqrt_f32(sumx2/2048,pX_RMS);
  	      X_sra=(xsr1/2048)*(xsr1/2048);
  	      X_kv=X_kv/2048;
  	      X_sv=X_sv/2048;
  	      X_ppv=maxx-minx;
  	      X_cf=maxabsx/X_RMS;
  	      X_if=(maxabsx/sumabsx)/2048;
  	      X_mf=maxabsx/X_sra;
  	      X_sf=(X_RMS/sumabsx)/2048;
  	      X_kf=X_kv/(X_RMS*X_RMS*X_RMS*X_RMS);

  	      feature[0]=X_RMS;
  	      feature[1]=X_sra;
  	      feature[2]=X_kv;
  	      feature[3]=X_sv;
	  feature[4]=X_ppv;
	  feature[5]= X_cf;
	  feature[6]=X_if;
	  feature[7]=X_mf;
	  feature[8]=X_sf;
	  feature[9]=X_kf;
	  xsr1=0;sumx2=0;sumabsx=0;X_RMS=0;X_sra=0;X_kv=0;X_sv=0;X_ppv=0;X_cf=0;X_if=0;X_mf=0;X_sf=0;X_kf=0;maxabsx=0;


// ----------------------------------------------wavelet-----------------------------------------
  	  	  s10[1]=0.483*ss00[1]+0.837*ss00[2]+0.224*ss00[3]-0.129*ss00[4];
  		  t11[1]=-0.129*ss00[1]-0.224*ss00[2]+0.837*ss00[3]-0.483*ss00[4];
  	  	  for(int k=2;k<=1024;k++)
  		  {
  	  		  s10[k]=0.483*ss00[2*k]+0.837*ss00[2*k+1]+0.224*ss00[2*k+2]-0.129*ss00[2*k+3];
  	  		  t11[k]=-0.129*ss00[2*k]-0.224*ss00[2*k+1]+0.837*ss00[2*k+2]-0.483*ss00[2*k+3];
  		  }

  	  	  s20[1]=0.483*s10[1]+0.837*s10[2]+0.224*s10[3]-0.129*s10[4];
  		  t21[1]=-0.129*s10[1]-0.224*s10[2]+0.837*s10[3]-0.483*s10[4];
  	  	  for(int k=2;k<=512;k++)
  		  {
  		  		s20[k]=0.483*s10[2*k]+0.837*s10[2*k+1]+0.224*s10[2*k+2]-0.129*s10[2*k+3];
  		  		t21[k]=-0.129*s10[2*k]-0.224*s10[2*k+1]+0.837*s10[2*k+2]-0.483*s10[2*k+3];
  		  }

  	  	  s22[1]=0.483*t11[1]+0.837*t11[2]+0.224*t11[3]-0.129*t11[4];
  		  t23[1]=-0.129*t11[1]-0.224*t11[2]+0.837*t11[3]-0.483*t11[4];
  	  	  for(int k=2;k<=512;k++)
  		  {
  		  		 s22[k]=0.483*t11[2*k]+0.837*t11[2*k+1]+0.224*t11[2*k+2]-0.129*t11[2*k+3];
  		  		 t23[k]=-0.129*t11[2*k]-0.224*t11[2*k+1]+0.837*t11[2*k+2]-0.483*t11[2*k+3];
  		  }

  	  	  s30[1]=0.483*s20[1]+0.837*s20[2]+0.224*s20[3]-0.129*s20[4];
  		  t31[1]=-0.129*s20[1]-0.224*s20[2]+0.837*s20[3]-0.483*s20[4];

  		  s32[1]=0.483*t21[1]+0.837*t21[2]+0.224*t21[3]-0.129*t21[4];
  		  t33[1]=-0.129*t21[1]-0.224*t21[2]+0.837*t21[3]-0.483*t21[4];

  		  s34[1]=0.483*s22[1]+0.837*s22[2]+0.224*s22[3]-0.129*s22[4];
  		  t35[1]=-0.129*s22[1]-0.224*s22[2]+0.837*s22[3]-0.483*s22[4];

  		  s36[1]=0.483*t23[1]+0.837*t23[2]+0.224*t23[3]-0.129*t23[4];
  		  t37[1]=-0.129*t23[1]-0.224*t23[2]+0.837*t23[3]-0.483*t23[4];
  	  	  for(int k=2;k<=256;k++)
  		  {
  		  		 s30[k]=0.483*s20[2*k]+0.837*s20[2*k+1]+0.224*s20[2*k+2]-0.129*s20[2*k+3];
  		  		 t31[k]=-0.129*s20[2*k]-0.224*s20[2*k+1]+0.837*s20[2*k+2]-0.483*s20[2*k+3];

  		  		 s32[k]=0.483*t21[2*k]+0.837*t21[2*k+1]+0.224*t21[2*k+2]-0.129*t21[2*k+3];
  		  		 t33[k]=-0.129*t21[2*k]-0.224*t21[2*k+1]+0.837*t21[2*k+2]-0.483*t21[2*k+3];

  		  		 s34[k]=0.483*s22[2*k]+0.837*s22[2*k+1]+0.224*s22[2*k+2]-0.129*s22[2*k+3];
  		  		 t35[k]=-0.129*s22[2*k]-0.224*s22[2*k+1]+0.837*s22[2*k+2]-0.483*s22[2*k+3];

  		  		 s36[k]=0.483*t23[2*k]+0.837*t23[2*k+1]+0.224*t23[2*k+2]-0.129*t23[2*k+3];
  		  		 t37[k]=-0.129*t23[2*k]-0.224*t23[2*k+1]+0.837*t23[2*k+2]-0.483*t23[2*k+3];
  		  }

  	  ss00[1]=0.483*s30[1]+0.837*s30[2]+0.224*s30[3]-0.129*s30[4];
  	  ss00[129]=-0.129*s30[1]-0.224*s30[2]+0.837*s30[3]-0.483*s30[4];
  	  ss00[257]=0.483*t31[1]+0.837*t31[2]+0.224*t31[3]-0.129*t31[4];
  	  ss00[385]=-0.129*t31[1]-0.224*t31[2]+0.837*t31[3]-0.483*t31[4];
  	  ss00[513]=0.483*s32[1]+0.837*s32[2]+0.224*s32[3]-0.129*s32[4];
  	  ss00[641]=-0.129*s32[1]-0.224*s32[2]+0.837*s32[3]-0.483*s32[4];
  	  ss00[769]=0.483*t33[1]+0.837*t33[2]+0.224*t33[3]-0.129*t33[4];
  	  ss00[897]=-0.129*t33[1]-0.224*t33[2]+0.837*t33[3]-0.483*t33[4];
  	  ss00[1025]=0.483*s34[1]+0.837*s34[2]+0.224*s34[3]-0.129*s34[4];
  	  ss00[1153]=-0.129*s34[1]-0.224*s34[2]+0.837*s34[3]-0.483*s34[4];
  	  ss00[1281]=0.483*t35[1]+0.837*t35[2]+0.224*t35[3]-0.129*t35[4];
  	  ss00[1409]=-0.129*t35[1]-0.224*t35[2]+0.837*t35[3]-0.483*t35[4];
  	  ss00[1537]=0.483*s36[1]+0.837*s36[2]+0.224*s36[3]-0.129*s36[4];
  	  ss00[1665]=-0.129*s36[1]-0.224*s36[2]+0.837*s36[3]-0.483*s36[4];
  	  ss00[1793]=0.483*t37[1]+0.837*t37[2]+0.224*t37[3]-0.129*t37[4];
  	  ss00[1921]=-0.129*t37[1]-0.224*t37[2]+0.837*t37[3]-0.483*t37[4];


  for (int j=2;j<=128;j++)
		  {
	  	  	  ss00[j]=0.483*s30[2*j]+0.837*s30[2*j+1]+0.224*s30[2*j+2]-0.129*s30[2*j+3];
	  	  	  ss00[j+128]=-0.129*s30[2*j]-0.224*s30[2*j+1]+0.837*s30[2*j+2]-0.483*s30[2*j+3];
	  	  	  ss00[j+256]=0.483*t31[2*j]+0.837*t31[2*j+1]+0.224*t31[2*j+2]-0.129*t31[2*j+3];
	  	  	  ss00[j+384]=-0.129*t31[2*j]-0.224*t31[2*j+1]+0.837*t31[2*j+2]-0.483*t31[2*j+3];
	  	  	  ss00[j+512]=0.483*s32[2*j]+0.837*s32[2*j+1]+0.224*s32[2*j+2]-0.129*s32[2*j+3];
	  	  	  ss00[j+640]=-0.129*s32[2*j]-0.224*s32[2*j+1]+0.837*s32[2*j+2]-0.483*s32[2*j+3];
	  	  	  ss00[j+768]=0.483*t33[2*j]+0.837*t33[2*j+1]+0.224*t33[2*j+2]-0.129*t33[2*j+3];
	  	  	  ss00[j+896]=-0.129*t33[2*j]-0.224*t33[2*j+1]+0.837*t33[2*j+2]-0.483*t33[2*j+3];
	  	  	  ss00[j+1024]=0.483*s34[2*j]+0.837*s34[2*j+1]+0.224*s34[2*j+2]-0.129*s34[2*j+3];
	  	  	  ss00[j+1152]=-0.129*s34[2*j]-0.224*s34[2*j+1]+0.837*s34[2*j+2]-0.483*s34[2*j+3];
	  	  	  ss00[j+1280]=0.483*t35[2*j]+0.837*t35[2*j+1]+0.224*t35[2*j+2]-0.129*t35[2*j+3];
	  	  	  ss00[j+1408]=-0.129*t35[2*j]-0.224*t35[2*j+1]+0.837*t35[2*j+2]-0.483*t35[2*j+3];
	  	  	  ss00[j+1536]=0.483*s36[2*j]+0.837*s36[2*j+1]+0.224*s36[2*j+2]-0.129*s36[2*j+3];
	  	  	  ss00[j+1664]=-0.129*s36[2*j]-0.224*s36[2*j+1]+0.837*s36[2*j+2]-0.483*s36[2*j+3];
	  	  	  ss00[j+1792]=0.483*t37[2*j]+0.837*t37[2*j+1]+0.224*t37[2*j+2]-0.129*t37[2*j+3];
	  	  	  ss00[j+1920]=-0.129*t37[2*j]-0.224*t37[2*j+1]+0.837*t37[2*j+2]-0.483*t37[2*j+3];

		  }


  	  	  for(int k=1;k<=128;k++)
  		  {
  	  		  	  energy[0]=ss00[k]*ss00[k] 		   + energy[0];
  	  		  	  energy[1]=ss00[k+128]*ss00[k+128]    + energy[1];
  	  		  	  energy[2]=ss00[k+256]*ss00[k+256]    + energy[2];
  	  		  	  energy[3]=ss00[k+384]*ss00[k+384]    + energy[3];
  	  		  	  energy[4]=ss00[k+512]*ss00[k+512]    + energy[4];
  	  		  	  energy[5]=ss00[k+640]*ss00[k+640]    + energy[5];
  	  		  	  energy[6]=ss00[k+768]*ss00[k+768]    + energy[6];
  	  		  	  energy[7]=ss00[k+896]*ss00[k+896]    + energy[7];
  	  		  	  energy[8]=ss00[k+1024]*ss00[k+1024]  + energy[8];
  	  		  	  energy[9]=ss00[k+1152]*ss00[k+1152]  + energy[9];
  	  		  	  energy[10]=ss00[k+1280]*ss00[k+1280] + energy[10];
  	  		  	  energy[11]=ss00[k+1408]*ss00[k+1408] + energy[11];
  	  		  	  energy[12]=ss00[k+1536]*ss00[k+1536] + energy[12];
  	  		  	  energy[13]=ss00[k+1664]*ss00[k+1664] + energy[13];
  	  		  	  energy[14]=ss00[k+1792]*ss00[k+1792] + energy[14];
  	  		  	  energy[15]=ss00[k+1920]*ss00[k+1920] + energy[15];
  		  }

// --------------------------------------------------------fft-------------------------------------------
  arm_rfft_fast_instance_f32 Sfft;
  arm_rfft_fast_init_f32(&Sfft, NUM_SAMPLES);

  arm_rfft_fast_f32 (&Sfft, xxx, leftFFT,0);
  arm_cmplx_mag_f32 (leftFFT, fftx, NUM_SAMPLES);

// -----------------------------------------------frequency domain features-------------------------------------------

//f= k*df    and    df=0.1953
  	  	  for(int k=0;k<1024;k++)
	  		  {
	  		  	  xfc1 = k*df*fftx[k]*df + xfc1;
	  		  	  xfc2 = df*fftx[k] + xfc2;
	  		  	  xrmsf1= k*df*k*df*fftx[k]*df + xrmsf1;
	  		  }

  	X_fc=xfc1/xfc2;
  	X_rmsf=xrmsf1/xfc2;
  	arm_sqrt_f32(X_rmsf,pX_rmsf);

  			for(int k=0;k<1024;k++)
	  		  	{
	  		  		  xrvf1= (k*df-X_fc)*(k*df-X_fc)*fftx[k]*df + xrvf1;
	  		  	}

  	X_rvf= xrvf1/xfc2;
  	arm_sqrt_f32(X_rvf,pX_rvf);

feature[10]=X_fc;
feature[11]=X_rmsf;
feature[12]=X_rvf;
feature[13]=energy[0];
feature[14]=energy[1];
feature[15]=energy[2];
feature[16]=energy[3];
feature[17]=energy[4];
feature[18]=energy[5];
feature[19]=energy[6];
feature[20]=energy[7];
feature[21]=energy[8];
feature[22]=energy[9];
feature[23]=energy[10];
feature[24]=energy[11];
feature[25]=energy[12];
feature[26]=energy[13];
feature[27]=energy[14];
feature[28]=energy[15];

	energy[0]=0;energy[1]=0;energy[2]=0;energy[3]=0;energy[4]=0;energy[5]=0;energy[6]=0;energy[7]=0;energy[8]=0;
	energy[9]=0;energy[10]=0;energy[11]=0;energy[12]=0;energy[13]=0;energy[14]=0;energy[15]=0;

	X_fc=0;X_rmsf=0;X_rvf=0;xrvf1=0;xfc1=0;xfc2=0;xrmsf1=0;

}



void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  /* Prevent unused argument(s) compilation warning */
  UNUSED(GPIO_Pin);
  /* NOTE: This function Should not be modified, when the callback is needed,
           the HAL_GPIO_EXTI_Callback could be implemented in the user file
   */
  myData = LIS3DSH_GetDataScaled();
  if(flag==1)
  {
	  //switch(axis)
	  //{
	  	if(axis==1)
	  	{
	  		xyz[i]=myData.x;
	  	}
	  	if(axis==2)
	  	{
	  		xyz[i]=myData.y;
	  	}
	  	if(axis==3)
	  	{
	  		xyz[i]=myData.z;
	  	}
  	i++;
  }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
